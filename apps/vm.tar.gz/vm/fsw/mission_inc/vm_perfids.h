#ifndef VM_PERFIDS_H
#define VM_PERFIDS_H

#ifdef __cplusplus
extern "C" {
#endif

#define VM_MAIN_TASK_PERF_ID      0

#ifdef __cplusplus
}
#endif

#endif /* VM_PERFIDS_H */

/************************/
/*  End of File Comment */
/************************/
